import InsuranceLanding from "../insurance-landing"

export default function Page() {
  return <InsuranceLanding />
}
